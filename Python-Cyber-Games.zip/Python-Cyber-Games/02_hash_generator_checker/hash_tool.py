#!/usr/bin/env python3
"""Hash Generator / Checker - standard library only."""

import hashlib
from pathlib import Path


ALGORITHMS = ("md5", "sha1", "sha256", "sha512")


def hash_file(path, algorithm):
    hasher = hashlib.new(algorithm)
    with open(path, "rb") as file:
        while chunk := file.read(1024 * 1024):
            hasher.update(chunk)
    return hasher.hexdigest()


def hash_text(text, algorithm):
    return hashlib.new(algorithm, text.encode("utf-8")).hexdigest()


def main():
    while True:
        print("\n" + "=" * 60)
        print("                 HASH GENERATOR / CHECKER")
        print("=" * 60)
        print("1. Hash text")
        print("2. Hash a file")
        print("3. Compare a file with an expected hash")
        print("4. Exit")
        choice = input("\nChoice: ").strip()

        if choice == "4":
            break

        if choice not in {"1", "2", "3"}:
            print("Invalid choice.")
            continue

        algorithm = input("Algorithm (md5/sha1/sha256/sha512): ").strip().lower()
        if algorithm not in ALGORITHMS:
            print("Unsupported algorithm.")
            continue

        if choice == "1":
            text = input("Text: ")
            print(f"\n{algorithm.upper()}: {hash_text(text, algorithm)}")

        else:
            path = Path(input("File path: ").strip().strip('"'))
            if not path.is_file():
                print("File not found.")
                continue
            digest = hash_file(path, algorithm)
            print(f"\n{algorithm.upper()}: {digest}")

            if choice == "3":
                expected = input("Expected hash: ").strip().lower()
                print("MATCH" if digest.lower() == expected else "NO MATCH")


if __name__ == "__main__":
    main()
