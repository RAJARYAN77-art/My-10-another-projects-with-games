#!/usr/bin/env python3
"""Number Guessing Game."""

import random


def choose_range():
    print("\n1. Easy   (1-50)")
    print("2. Medium (1-100)")
    print("3. Hard   (1-500)")
    while True:
        choice = input("Difficulty: ").strip()
        if choice == "1":
            return 50
        if choice == "2":
            return 100
        if choice == "3":
            return 500
        print("Choose 1, 2, or 3.")


def play():
    maximum = choose_range()
    secret = random.randint(1, maximum)
    attempts = 0

    print(f"\nGuess a number from 1 to {maximum}.")
    while True:
        raw = input("Your guess: ").strip()
        try:
            guess = int(raw)
        except ValueError:
            print("Enter a whole number.")
            continue

        if not 1 <= guess <= maximum:
            print(f"Use a number from 1 to {maximum}.")
            continue

        attempts += 1
        if guess < secret:
            print("Too low!")
        elif guess > secret:
            print("Too high!")
        else:
            print(f"\n🎉 Correct! Number: {secret}")
            print(f"Attempts: {attempts}")
            return


def main():
    print("=" * 55)
    print("                    NUMBER GUESSING")
    print("=" * 55)
    while True:
        play()
        if input("\nPlay again? (y/n): ").strip().lower() != "y":
            break


if __name__ == "__main__":
    main()
