#!/usr/bin/env python3
"""Two-player Tic-Tac-Toe."""


WINNING_LINES = (
    (0, 1, 2), (3, 4, 5), (6, 7, 8),
    (0, 3, 6), (1, 4, 7), (2, 5, 8),
    (0, 4, 8), (2, 4, 6),
)


def display(board):
    print("\n")
    for row in range(3):
        cells = board[row * 3:(row + 1) * 3]
        print(f" {cells[0]} | {cells[1]} | {cells[2]}")
        if row < 2:
            print("---+---+---")


def winner(board):
    for a, b, c in WINNING_LINES:
        if board[a] == board[b] == board[c] and board[a] in "XO":
            return board[a]
    return None


def main():
    board = list("123456789")
    player = "X"

    print("=" * 40)
    print("                 TIC-TAC-TOE")
    print("=" * 40)

    for turn in range(9):
        display(board)
        while True:
            choice = input(f"\nPlayer {player}, choose 1-9: ").strip()
            if choice.isdigit() and 1 <= int(choice) <= 9:
                index = int(choice) - 1
                if board[index] not in "XO":
                    board[index] = player
                    break
            print("Invalid or occupied position.")

        if winner(board):
            display(board)
            print(f"\n🏆 Player {player} wins!")
            return

        player = "O" if player == "X" else "X"

    display(board)
    print("\nDraw!")


if __name__ == "__main__":
    main()
