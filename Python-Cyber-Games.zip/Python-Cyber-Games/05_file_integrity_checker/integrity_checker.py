#!/usr/bin/env python3
"""File Integrity Checker using SHA-256 baselines."""

import hashlib
import json
from datetime import datetime
from pathlib import Path

DATABASE = Path("integrity_database.json")


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as file:
        while chunk := file.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def load():
    if not DATABASE.exists():
        return {}
    try:
        return json.loads(DATABASE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def save(data):
    DATABASE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def create_baseline():
    path = Path(input("File path: ").strip().strip('"')).resolve()
    if not path.is_file():
        print("File not found.")
        return
    data = load()
    data[str(path)] = {
        "sha256": sha256(path),
        "recorded": datetime.now().isoformat(timespec="seconds"),
    }
    save(data)
    print(f"Baseline saved for: {path}")
    print(f"SHA-256: {data[str(path)]['sha256']}")


def check():
    path = Path(input("File path: ").strip().strip('"')).resolve()
    data = load()
    record = data.get(str(path))
    if not record:
        print("No baseline exists for this file.")
        return
    if not path.is_file():
        print("WARNING: File no longer exists.")
        return
    current = sha256(path)
    print(f"Baseline: {record['sha256']}")
    print(f"Current : {current}")
    print("[OK] File unchanged." if current == record["sha256"] else "[WARNING] File changed!")


def list_baselines():
    data = load()
    if not data:
        print("No baselines.")
        return
    for path, record in data.items():
        print(f"- {path}\n  {record['sha256']}")


def main():
    while True:
        print("\n" + "=" * 60)
        print("                    FILE INTEGRITY CHECKER")
        print("=" * 60)
        print("1. Create baseline")
        print("2. Check file")
        print("3. List baselines")
        print("4. Exit")
        choice = input("\nChoice: ").strip()

        if choice == "1":
            create_baseline()
        elif choice == "2":
            check()
        elif choice == "3":
            list_baselines()
        elif choice == "4":
            break
        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
