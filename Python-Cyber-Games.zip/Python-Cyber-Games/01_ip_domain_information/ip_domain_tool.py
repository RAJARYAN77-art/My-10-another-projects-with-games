#!/usr/bin/env python3
"""IP / Domain Information Tool - standard library only."""

import ipaddress
import socket
import ssl
import urllib.parse
import urllib.request
from datetime import datetime


def resolve_target(target: str) -> str:
    target = target.strip()
    if "://" in target:
        target = urllib.parse.urlparse(target).hostname or ""
    target = target.strip().strip("/")
    if not target:
        raise ValueError("Empty target.")
    return target


def dns_info(target):
    print("\n[ DNS / HOST INFORMATION ]")
    try:
        host, aliases, addresses = socket.gethostbyname_ex(target)
        print(f"Hostname : {host}")
        print(f"Aliases  : {', '.join(aliases) or 'None'}")
        print("IPv4     :")
        for addr in addresses:
            print(f"  - {addr}")
    except socket.gaierror as exc:
        print(f"DNS resolution failed: {exc}")


def ip_info(target):
    print("\n[ IP INFORMATION ]")
    try:
        ip = ipaddress.ip_address(target)
        print(f"Address  : {ip}")
        print(f"Version  : IPv{ip.version}")
        print(f"Private  : {ip.is_private}")
        print(f"Global   : {ip.is_global}")
        print(f"Loopback : {ip.is_loopback}")
        print(f"Reserved : {ip.is_reserved}")
        try:
            print(f"Reverse  : {socket.gethostbyaddr(str(ip))[0]}")
        except socket.herror:
            print("Reverse  : Unavailable")
    except ValueError:
        print("Target is not a literal IP address.")


def http_info(target):
    print("\n[ HTTPS INFORMATION ]")
    url = f"https://{target}"
    try:
        req = urllib.request.Request(
            url, headers={"User-Agent": "Python-IP-Domain-Tool/1.0"}
        )
        with urllib.request.urlopen(req, timeout=10) as response:
            print(f"URL         : {response.geturl()}")
            print(f"Status      : {response.status}")
            print(f"Content-Type: {response.headers.get('Content-Type', 'Unknown')}")
            print(f"Server      : {response.headers.get('Server', 'Unknown')}")
    except Exception as exc:
        print(f"HTTPS request failed: {exc}")


def tls_info(target):
    print("\n[ TLS CERTIFICATE INFORMATION ]")
    context = ssl.create_default_context()
    try:
        with socket.create_connection((target, 443), timeout=10) as raw:
            with context.wrap_socket(raw, server_hostname=target) as sock:
                cert = sock.getpeercert()
                print(f"TLS Version : {sock.version()}")
                print(f"Cipher      : {sock.cipher()[0]}")
                print("Certificate : present")
                print(f"Subject     : {cert.get('subject', 'Unavailable')}")
                print(f"Issuer      : {cert.get('issuer', 'Unavailable')}")
    except Exception as exc:
        print(f"TLS information unavailable: {exc}")


def main():
    print("=" * 68)
    print("                 IP / DOMAIN INFORMATION TOOL")
    print("=" * 68)
    print("Use only on domains/IPs you own or are authorized to investigate.")
    target = resolve_target(input("\nTarget domain or IP: "))
    print(f"\nTarget: {target}")
    print(f"Time  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    dns_info(target)
    ip_info(target)
    if not target.replace(".", "").isdigit():
        http_info(target)
        tls_info(target)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nCancelled.")
    except ValueError as exc:
        print(f"Error: {exc}")
