#!/usr/bin/env python3
"""Hangman word game."""

import random

WORDS = (
    "python", "network", "firewall", "terminal", "security",
    "database", "programming", "computer", "encryption", "cybersecurity",
)

MAX_MISSES = 6


def display(secret, guessed):
    return " ".join(letter if letter in guessed else "_" for letter in secret)


def play():
    secret = random.choice(WORDS)
    guessed = set()
    misses = 0

    print("\nGuess the hidden word.")
    while misses < MAX_MISSES:
        print(f"\nWord: {display(secret, guessed)}")
        print(f"Misses: {misses}/{MAX_MISSES}")
        print(f"Guessed: {', '.join(sorted(guessed)) or 'None'}")

        letter = input("Enter one letter: ").strip().lower()
        if len(letter) != 1 or not letter.isalpha():
            print("Enter exactly one alphabetic character.")
            continue
        if letter in guessed:
            print("You already guessed that letter.")
            continue

        guessed.add(letter)

        if letter in secret:
            print("Correct!")
            if all(ch in guessed for ch in secret):
                print(f"\n🎉 You won! Word: {secret}")
                return
        else:
            misses += 1
            print("Wrong guess.")

    print(f"\n💀 Game over. The word was: {secret}")


def main():
    print("=" * 45)
    print("                     HANGMAN")
    print("=" * 45)
    while True:
        play()
        if input("\nPlay again? (y/n): ").strip().lower() != "y":
            break


if __name__ == "__main__":
    main()
