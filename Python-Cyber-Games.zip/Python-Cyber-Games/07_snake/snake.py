#!/usr/bin/env python3
"""Snake game using Python's built-in turtle module."""

import random
import turtle
import time

WIDTH, HEIGHT = 600, 600
STEP = 20
delay = 0.10
direction = "stop"
score = 0
high_score = 0
segments = []

screen = turtle.Screen()
screen.title("Python Snake")
screen.bgcolor("black")
screen.setup(WIDTH, HEIGHT)
screen.tracer(0)

head = turtle.Turtle("square")
head.color("green")
head.penup()

food = turtle.Turtle("circle")
food.color("red")
food.penup()

score_pen = turtle.Turtle(visible=False)
score_pen.color("white")
score_pen.penup()
score_pen.goto(0, 260)


def draw_score():
    score_pen.clear()
    score_pen.write(
        f"Score: {score}  High Score: {high_score}",
        align="center",
        font=("Arial", 18, "normal"),
    )


def place_food():
    food.goto(
        random.randrange(-WIDTH // 2 + STEP, WIDTH // 2 - STEP, STEP),
        random.randrange(-HEIGHT // 2 + STEP, HEIGHT // 2 - STEP, STEP),
    )


def set_direction(new):
    global direction
    opposites = {"up": "down", "down": "up", "left": "right", "right": "left"}
    if new != opposites.get(direction):
        direction = new


def move_head():
    x, y = head.xcor(), head.ycor()
    if direction == "up":
        head.sety(y + STEP)
    elif direction == "down":
        head.sety(y - STEP)
    elif direction == "left":
        head.setx(x - STEP)
    elif direction == "right":
        head.setx(x + STEP)


def reset():
    global direction, score
    head.goto(0, 0)
    direction = "stop"
    score = 0
    for segment in segments:
        segment.goto(1000, 1000)
    segments.clear()
    place_food()
    draw_score()


def add_segment():
    segment = turtle.Turtle("square")
    segment.color("lightgreen")
    segment.penup()
    segments.append(segment)


def on_key(key):
    set_direction(key)


for key in ("Up", "Down", "Left", "Right"):
    screen.onkeypress(lambda k=key: on_key({
        "Up": "up", "Down": "down", "Left": "left", "Right": "right"
    }[k]), key)

screen.listen()
place_food()
draw_score()

while True:
    screen.update()

    # Move body from tail toward head.
    for i in range(len(segments) - 1, 0, -1):
        segments[i].goto(segments[i - 1].pos())
    if segments:
        segments[0].goto(head.pos())

    move_head()

    if (
        abs(head.xcor()) > WIDTH // 2 - STEP
        or abs(head.ycor()) > HEIGHT // 2 - STEP
    ):
        reset()

    if head.distance(food) < STEP:
        global_score = None  # keeps this section explicit for beginners
        add_segment()
        score += 10
        if score > high_score:
            high_score = score
        place_food()
        draw_score()

    if any(segment.distance(head) < STEP for segment in segments):
        reset()

    time.sleep(delay)
