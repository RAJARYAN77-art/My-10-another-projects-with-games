import subprocess
import sys
from pathlib import Path

PROJECTS = {
    "1": "01_ip_domain_information/ip_domain_tool.py",
    "2": "02_hash_generator_checker/hash_tool.py",
    "3": "03_basic_osint/osint_tool.py",
    "4": "04_network_monitor/network_monitor.py",
    "5": "05_file_integrity_checker/integrity_checker.py",
    "6": "06_python_hero/python_hero.py",
    "7": "07_snake/snake.py",
    "8": "08_number_guessing/number_guessing.py",
    "9": "09_tic_tac_toe/tic_tac_toe.py",
    "10": "10_hangman/hangman.py",
}

print("PYTHON CYBER GAMES")
for n, path in PROJECTS.items():
    print(f"{n}. {path}")
choice = input("Choose project: ").strip()
if choice in PROJECTS:
    subprocess.run([sys.executable, str(Path(__file__).parent / PROJECTS[choice])])
else:
    print("Invalid choice.")
