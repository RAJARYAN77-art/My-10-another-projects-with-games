#!/usr/bin/env python3
"""Basic passive OSINT helper using public DNS/HTTPS information."""

import json
import socket
import ssl
import urllib.parse
import urllib.request
from datetime import datetime


def normalize(value):
    if "://" in value:
        value = urllib.parse.urlparse(value).hostname or ""
    return value.strip().strip("/")


def collect(domain):
    result = {
        "target": domain,
        "generated": datetime.now().isoformat(timespec="seconds"),
        "dns": {},
        "https": {},
        "tls": {},
    }

    try:
        host, aliases, addresses = socket.gethostbyname_ex(domain)
        result["dns"] = {"hostname": host, "aliases": aliases, "ipv4": addresses}
    except socket.gaierror as exc:
        result["dns"] = {"error": str(exc)}

    try:
        req = urllib.request.Request(
            f"https://{domain}",
            headers={"User-Agent": "Basic-OSINT-Tool/1.0"},
        )
        with urllib.request.urlopen(req, timeout=10) as response:
            result["https"] = {
                "final_url": response.geturl(),
                "status": response.status,
                "server": response.headers.get("Server"),
                "content_type": response.headers.get("Content-Type"),
            }
    except Exception as exc:
        result["https"] = {"error": str(exc)}

    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=10) as raw:
            with context.wrap_socket(raw, server_hostname=domain) as sock:
                cert = sock.getpeercert()
                result["tls"] = {
                    "version": sock.version(),
                    "cipher": sock.cipher()[0],
                    "subject": cert.get("subject"),
                    "issuer": cert.get("issuer"),
                }
    except Exception as exc:
        result["tls"] = {"error": str(exc)}

    return result


def main():
    print("=" * 65)
    print("                     BASIC OSINT TOOL")
    print("=" * 65)
    print("Passive information only. Use targets you are authorized to investigate.")
    domain = normalize(input("\nDomain: "))
    if not domain:
        print("Invalid domain.")
        return

    data = collect(domain)
    print(json.dumps(data, indent=2, default=str))

    with open("osint_report.json", "w", encoding="utf-8") as file:
        json.dump(data, file, indent=2, default=str)
    print("\nSaved: osint_report.json")


if __name__ == "__main__":
    main()
