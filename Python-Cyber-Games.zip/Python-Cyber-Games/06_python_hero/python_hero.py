#!/usr/bin/env python3
"""Original Python-learning RPG. Commands resemble simple Python functions."""

import random


class Hero:
    def __init__(self):
        self.level = 1
        self.hp = 100
        self.mana = 50
        self.xp = 0
        self.gold = 0

    def status(self):
        print(f"\nLevel {self.level} | HP {self.hp}/100 | Mana {self.mana}/50 | XP {self.xp} | Gold {self.gold}")

    def reward(self, xp, gold):
        self.xp += xp
        self.gold += gold
        while self.xp >= self.level * 100:
            self.xp -= self.level * 100
            self.level += 1
            print(f"LEVEL UP! You are now level {self.level}.")


class Enemy:
    def __init__(self, name, hp, damage):
        self.name = name
        self.hp = hp
        self.damage = damage


def attack(hero, enemy):
    damage = random.randint(10, 20) + hero.level * 2
    enemy.hp -= damage
    print(f"attack() -> {damage} damage")


def fireball(hero, enemy):
    if hero.mana < 15:
        print("Not enough mana.")
        return
    hero.mana -= 15
    damage = random.randint(25, 40)
    enemy.hp -= damage
    print(f"fireball() -> {damage} damage")


def heal(hero):
    if hero.mana < 10:
        print("Not enough mana.")
        return
    hero.mana -= 10
    amount = random.randint(15, 30)
    hero.hp = min(100, hero.hp + amount)
    print(f"heal() -> +{amount} HP")


def battle(hero, enemy):
    print(f"\n⚔️ {enemy.name} appears!")
    while hero.hp > 0 and enemy.hp > 0:
        print(f"\nYour HP: {hero.hp} | {enemy.name}: {enemy.hp}")
        command = input("Python command (attack(), fireball(), heal(), status()): ").strip().lower()
        if command == "attack()":
            attack(hero, enemy)
        elif command == "fireball()":
            fireball(hero, enemy)
        elif command == "heal()":
            heal(hero)
        elif command == "status()":
            hero.status()
            continue
        else:
            print("Unknown command.")
            continue

        if enemy.hp <= 0:
            print(f"🏆 {enemy.name} defeated!")
            hero.reward(50, random.randint(20, 50))
            return True

        hit = random.randint(max(1, enemy.damage // 2), enemy.damage)
        hero.hp -= hit
        print(f"{enemy.name} hits you for {hit}.")
    return False


def main():
    hero = Hero()
    print("=" * 60)
    print("                       PYTHON HERO")
    print("=" * 60)
    print("Learn Python concepts while playing an original terminal RPG.")

    while hero.hp > 0:
        print("\n1. Start mission\n2. Status\n3. Exit")
        choice = input("Choice: ").strip()
        if choice == "1":
            enemy = Enemy("Cyber Guardian", 100 + hero.level * 10, 20 + hero.level * 3)
            if not battle(hero, enemy):
                print("💀 Game over.")
                break
        elif choice == "2":
            hero.status()
        elif choice == "3":
            break


if __name__ == "__main__":
    main()
