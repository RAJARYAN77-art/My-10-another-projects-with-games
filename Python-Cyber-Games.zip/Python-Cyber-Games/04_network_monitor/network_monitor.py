#!/usr/bin/env python3
"""Local network monitor. Shows this computer's active connections."""

import socket
import time
from datetime import datetime

try:
    import psutil
except ImportError:
    psutil = None


def format_addr(addr):
    if not addr:
        return "-"
    if hasattr(addr, "ip"):
        return f"{addr.ip}:{addr.port}"
    if isinstance(addr, tuple):
        return f"{addr[0]}:{addr[1]}"
    return str(addr)


def monitor():
    print("=" * 90)
    print("                         LOCAL NETWORK MONITOR")
    print("=" * 90)
    print("Press Ctrl+C to stop. This displays local socket information only.")

    while True:
        print("\n" + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        print(f"{'PROTO':<7}{'LOCAL':<28}{'REMOTE':<35}{'STATUS':<16}")
        print("-" * 90)

        if psutil is None:
            print("psutil is not installed. Run: pip install psutil")
        else:
            try:
                connections = psutil.net_connections(kind="inet")
                shown = 0
                for conn in connections:
                    proto = "TCP" if conn.type == socket.SOCK_STREAM else "UDP"
                    local = format_addr(conn.laddr)
                    remote = format_addr(conn.raddr)
                    status = conn.status or "-"
                    print(f"{proto:<7}{local:<28}{remote:<35}{status:<16}")
                    shown += 1
                    if shown >= 80:
                        break
                if shown == 0:
                    print("No connections returned.")
            except (psutil.AccessDenied, PermissionError):
                print("Access denied. Some operating-system connections require elevated privileges.")

        time.sleep(3)


if __name__ == "__main__":
    try:
        monitor()
    except KeyboardInterrupt:
        print("\nMonitor stopped.")
